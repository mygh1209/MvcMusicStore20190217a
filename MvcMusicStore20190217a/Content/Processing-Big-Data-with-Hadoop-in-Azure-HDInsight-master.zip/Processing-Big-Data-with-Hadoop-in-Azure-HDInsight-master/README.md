# Processing-Big-Data-with-Hadoop-in-Azure-HDInsight
Shared files for Processing Big Data with Hadoop in Azure HDInsight course
